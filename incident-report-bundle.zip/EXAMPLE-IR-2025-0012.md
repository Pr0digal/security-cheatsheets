# 🛡️ Cybersecurity Incident Report – IR-2025-0012

---

## ✅ 1. Incident Metadata

| Field              | Value                       |
|--------------------|-----------------------------|
| **Incident ID**     | IR-2025-0012                |
| **Reported By**     | SOC Analyst – John Vega     |
| **Detection Time**  | 2025-05-25 02:16 AEST       |
| **Detection Source**| SentinelOne EDR             |
| **Severity**        | High                        |
| **Current Status**  | Resolved                    |

---

## 🔍 2. Executive Summary

At 2:16 AM AEST, the EDR platform triggered a high-confidence alert involving suspicious PowerShell activity from server `SRV-ADFS01`. The script was obfuscated and made an outbound HTTP request to a known C2 domain. Immediate containment and triage were initiated. No lateral movement was observed.

---

## 🧠 3. Incident Classification

| Category       | Details                          |
|----------------|-----------------------------------|
| **Type**        | Malware (Fileless)               |
| **Initial Vector** | Phishing w/ macro-laced Excel |
| **MITRE ATT&CK**   | T1059.001, T1071.001           |
| **Impacted Assets**| `SRV-ADFS01`, `User-JSmith-PC` |
| **Affected Users** | `jsmith`, `svc-deploy`         |

---

## 🧾 4. Technical Details

### 🔁 Timeline of Events
```
02:16 - EDR alert: Encoded PowerShell via `WINWORD.EXE`
02:18 - Host isolation command issued
02:30 - Memory dump initiated
03:00 - Account `jsmith` disabled
03:45 - Forensics team collected volatile logs
```

### 🧬 Indicators of Compromise (IOCs)
- IP: `185.163.45.22`
- Domain: `ms-update.secure[.]cloud`
- SHA256: `a8dbf54e312c...`

### 📄 Relevant Logs
- PowerShell Event ID 4104
- Win Event Log ID 4688, 4624, 1102
- Alert screenshot in `/attachments/edr-alert.png`

---

## 🛑 5. Containment & Mitigation

| Step               | Action Taken                            |
|--------------------|------------------------------------------|
| **Host Isolation**  | `SRV-ADFS01` disconnected from VLAN      |
| **User Actions**    | Password reset + MFA enforced for `jsmith` |
| **Blocking**        | IP/domain blocked in Palo Alto NGFW     |
| **Patching**        | KB5034734 applied post-incident          |

---

## 🧪 6. Root Cause Analysis

The compromise originated from a phishing email sent to `jsmith`, who opened an `.xlsm` file triggering an encoded PowerShell payload. The endpoint lacked macro execution hardening, allowing the script to reach an external domain and download a second-stage payload (blocked).

---

## 🧼 7. Remediation & Lessons Learned

| Area             | Recommendation                         |
|------------------|-----------------------------------------|
| Email Security    | Harden macro settings in GPO            |
| User Training     | Monthly phishing simulation & training  |
| EDR Automation    | SOAR auto-isolation of PowerShell alerts |
| Account Hardening | Audit service accounts for MFA gaps     |

---

## 📎 8. Attachments / Evidence

- [x] `attachments/edr-alert.png`
- [x] `attachments/memory-dump.hash`
- [x] `attachments/malicious-script.ps1`

---

## 🚦 9. Final Status

| Field            | Details                                     |
|------------------|---------------------------------------------|
| **Resolved On**   | 2025-05-25 17:00 AEST                       |
| **Resolution**    | Host rebuilt, users recredentialed, no persistence found |
| **Notified Parties** | CISO, Security Lead, Legal (FYI only)   |
| **Closed By**     | Jane Doe (SOC Lead)                         |

---

## 📚 Appendix

- [MITRE: T1059.001 – PowerShell](https://attack.mitre.org/techniques/T1059/001/)
- [VirusTotal Report](https://www.virustotal.com/gui/home/upload)
